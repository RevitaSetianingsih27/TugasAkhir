/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasAkhir;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 *
 * @author acer
 */
public class KartuAnggotaformController implements Initializable {

    @FXML
    private ProgressIndicator progress;
    @FXML
    private ProgressBar progressbar;
    @FXML
    private TextField textfield;

    @FXML
    private TextField tfIDAnggota;

    @FXML
    private TextField tfNama;

    @FXML
    private TextField tfUsia;

    @FXML
    private TextField tfNomorHP;

    @FXML
    private TextField tfAlamat;

    @FXML
    private TextField tfEmail;

    @FXML
    private Button btnPinjam;

    @FXML
    private Button btnReloadData;

    @FXML
    private TableView<?> tblKartuAnggota;

    @FXML
    private TableColumn<?, ?> colIDAnggota;

    @FXML
    private TableColumn<?, ?> colNama;

    @FXML
    private TableColumn<?, ?> colUsia;

    @FXML
    private TableColumn<?, ?> colGender;

    @FXML
    private TableColumn<?, ?> colNomorHP;

    @FXML
    private TableColumn<?, ?> colAlamat;

    @FXML
    private TableColumn<?, ?> colEmail;

    @FXML
    private TextField tfIDBuku;

    @FXML
    private TextField tfJudulBuku;

    @FXML
    private TextField tfPenerbit;

    @FXML
    private TableView<?> tblPeminjaman;

    @FXML
    private TableColumn<?, ?> colIDBuku;

    @FXML
    private TableColumn<?, ?> colJudulBuku;

    @FXML
    private TableColumn<?, ?> colPenerbit;

    @FXML
    private TableColumn<?, ?> colTanggalPinjam;

    @FXML
    private TableColumn<?, ?> colTanggalKembali;

    @FXML
    private DatePicker dpTanggalPinjam;

    @FXML
    private DatePicker dpTanggalKembali;

    @FXML
    private TextField tfGender;

    @FXML
    private Label lblDBStatus;
    
    private PeminjamanDataModel pdm;

    @FXML
    void handleTambahKPButton(ActionEvent event) {
        try {
            tfIDAnggota.setText("1000001"+pdm.nextPeminjamanIDAnggota());
        } catch (SQLException ex) {
            Logger.getLogger(KartuAnggotaformController.class.getName()).log(Level.SEVERE, null, ex);
        }
        LocalDate ld = dpTanggalPinjam.getValue();
        LocalDate dd = dpTanggalKembali.getValue();
        String TanggalPinjam = String.format("%d-%02d-%02d", ld.getYear(), ld.getMonthValue(), ld.getDayOfMonth());
        String TanggalKembali = String.format("%d-%02d-%02d", ld.getYear(), ld.getMonthValue(), ld.getDayOfMonth());
        Mahasiswa mh = new Mahasiswa(Integer.parseInt(tfIDAnggota.getText()),
                tfNama.getText(),
                Integer.parseInt(tfUsia.getText()),
                tfGender.getText(),
                Integer.parseInt(tfNomorHP.getText()),
                tfAlamat.getText(), tfEmail.getText(),
                new Peminjaman(Integer.parseInt(tfIDBuku.getText()), tfJudulBuku.getText(), tfPenerbit.getText(), TanggalPinjam, TanggalKembali));
        try {
            pdm.addKartuAnggota(mh);
        } catch (SQLException ex) {
            Logger.getLogger(KartuAnggotaformController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void handleReloadButton(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            pdm = new PeminjamanDataModel("MYSL");
            lblDBStatus.setText(pdm.conn == null ? "Not Connected" : "Connected");
            tfIDAnggota.setText("" + pdm.nextPeminjamanIDAnggota());
            dpTanggalPinjam.setValue(LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), LocalDate.now().getDayOfMonth()));
            dpTanggalKembali.setValue(LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), LocalDate.now().getDayOfMonth()));
            
        } catch (SQLException ex) {
            Logger.getLogger(KartuAnggotaformController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
