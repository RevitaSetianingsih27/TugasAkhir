/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasAkhir;

import TugasAkhir.db.dbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author acer
 */
public class PeminjamanDataModel {

    public final Connection conn;

    public PeminjamanDataModel(String driver) throws SQLException {
        this.conn = dbConnection.getConnection(driver);
    }

    public void addKartuAnggota(Mahasiswa mh) throws SQLException {
        String insertAnggota = "INSERT INTO KartuAnggota (ID_Anggota, Nama, Usia, Gender, NomorHP, Alamat)"
                + "VALUES (?,?,?,?,?,?)";
        String insertMahasiswa = "INSERT INTO Mahasiswa (ID_Anggota, Email)"
                + "VALUES (?,?)";
        String insertPeminjaman = "INSERT INTO Peminjaman (ID_Buku, Judul_Buku, Penerbit, TanggalPinjam, TanggalKembali, ID_Anggota)"
                + "VALUES (?,?,?,?,?,?)";
        PreparedStatement stmtAnggota = conn.prepareStatement(insertAnggota);
        stmtAnggota.setInt(1, mh.getID_Anggota());
        stmtAnggota.setString(2, mh.getNama());
        stmtAnggota.setInt(3, mh.getUsia());
        stmtAnggota.setString(4, mh.getGender());
        stmtAnggota.setInt(5, mh.getNomorHP());
        stmtAnggota.setString(6, mh.getAlamat());
        stmtAnggota.execute();

        PreparedStatement stmtMahasiswa = conn.prepareStatement(insertMahasiswa);
        stmtMahasiswa.setInt(1, mh.getID_Anggota());
        stmtMahasiswa.setString(2, mh.getEmail());
        stmtMahasiswa.execute();

        PreparedStatement stmtPeminjaman = conn.prepareStatement(insertPeminjaman);
        stmtPeminjaman.setInt(1, mh.getPinjam().get(0).getIDBuku());
        stmtPeminjaman.setString(2, mh.getPinjam().get(0).getJudulBuku());
        stmtPeminjaman.setString(3, mh.getPinjam().get(0).getPenerbit());
        stmtPeminjaman.setString(4, mh.getPinjam().get(0).getTanggalPinjam());
        stmtPeminjaman.setString(5, mh.getPinjam().get(0).getTanggalKembali());
        stmtPeminjaman.setInt(6, mh.getID_Anggota());
        stmtPeminjaman.execute();
    }

    public void addKartuAnggota(NonMahasiswa mh) throws SQLException {
        String insertAnggota = "INSERT INTO KartuAnggota (ID_Anggota, Nama, Usia, Gender, NomorHP, Alamat)"
                + "VALUES (?,?,?,?,?,?)";
        String insertNonMahasiswa = "INSERT INTO Mahasiswa (ID_Anggota)"
                + "VALUES (?)";
        String insertPeminjaman = "INSERT INTO Peminjaman (ID_Buku, Judul_Buku, Penerbit, TanggalPinjam, TanggalKembali, ID_Anggota)"
                + "VALUES (?,?,?,?,?,?)";
        PreparedStatement stmtAnggota = conn.prepareStatement(insertAnggota);
        stmtAnggota.setInt(1, mh.getID_Anggota());
        stmtAnggota.setString(2, mh.getNama());
        stmtAnggota.setInt(3, mh.getUsia());
        stmtAnggota.setString(4, mh.getGender());
        stmtAnggota.setInt(5, mh.getNomorHP());
        stmtAnggota.setString(6, mh.getAlamat());
        stmtAnggota.execute();

        PreparedStatement stmtMahasiswa = conn.prepareStatement(insertNonMahasiswa);
        stmtMahasiswa.setInt(1, mh.getID_Anggota());
        stmtMahasiswa.execute();

        PreparedStatement stmtPeminjaman = conn.prepareStatement(insertPeminjaman);
        stmtPeminjaman.setInt(1, mh.getPinjam().get(0).getIDBuku());
        stmtPeminjaman.setString(2, mh.getPinjam().get(0).getJudulBuku());
        stmtPeminjaman.setString(3, mh.getPinjam().get(0).getPenerbit());
        stmtPeminjaman.setString(4, mh.getPinjam().get(0).getTanggalPinjam());
        stmtPeminjaman.setString(5, mh.getPinjam().get(0).getTanggalKembali());
        stmtPeminjaman.setInt(6, mh.getID_Anggota());
        stmtPeminjaman.execute();
    }

    public ObservableList<Mahasiswa> getMahasiswa() {
        ObservableList<Mahasiswa> data = FXCollections.observableArrayList();
        String sql = "SELECT `ID_Anggota`, `Email` FROM `kartuanggota`"
                + "NATURAL JOIN `mahasiswa` ORDER BY Nama";
        try {
            ResultSet r = conn.createStatement().executeQuery(sql);
            while (r.next()) {
                String sqlPeminjaman = "SELECT ID_Buku, JudulBuku, Penerbit,"
                        + "TanggalPinjam, TanggalKembali FROM Peminjaman WHERE ID_Anggota="
                        + r.getInt(1);
                ResultSet rPeminjaman = conn.createStatement().executeQuery(sqlPeminjaman);
                ArrayList<Peminjaman> dataPeminjaman = new ArrayList<>();
                while (rPeminjaman.next()) {
                    dataPeminjaman.add(new Peminjaman(rPeminjaman.getInt(1), rPeminjaman.getString(2),
                            rPeminjaman.getString(3), rPeminjaman.getString(4), rPeminjaman.getString(5)));
                }
                data.add(new Mahasiswa(r.getInt(1), r.getString(2), r.getInt(3), r.getString(4),
                        r.getInt(5), r.getString(6), r.getString(7), dataPeminjaman));
            }

        } catch (SQLException ex) {
            Logger.getLogger(PeminjamanDataModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }

    public ObservableList<NonMahasiswa> getNonMahasiswa() {
        ObservableList<NonMahasiswa> data = FXCollections.observableArrayList();
        String sql = "SELECT `ID_Anggota` FROM `kartuanggota`"
                + "NATURAL JOIN `nonmahasiswa` ORDER BY Nama";
        try {
            ResultSet r = conn.createStatement().executeQuery(sql);
            while (r.next()) {
                String sqlPeminjaman = "SELECT ID_Buku, JudulBuku, Penerbit,"
                        + "TanggalPinjam, TanggalKembali FROM Peminjaman WHERE ID_Anggota="
                        + r.getInt(1);
                ResultSet rPeminjaman = conn.createStatement().executeQuery(sqlPeminjaman);
                ArrayList<Peminjaman> dataPeminjaman = new ArrayList<>();
                while (rPeminjaman.next()) {
                    dataPeminjaman.add(new Peminjaman(rPeminjaman.getInt(1), rPeminjaman.getString(2),
                            rPeminjaman.getString(3), rPeminjaman.getString(4), rPeminjaman.getString(5)));
                }
                data.add(new NonMahasiswa(r.getInt(1), r.getString(2), r.getInt(3), r.getString(4),
                        r.getInt(5), r.getString(6), dataPeminjaman));
            }

        } catch (SQLException ex) {
            Logger.getLogger(PeminjamanDataModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }

    public ObservableList<Peminjaman> getPeminjaman(int ID_Anggota) {
        ObservableList<Peminjaman> data = FXCollections.observableArrayList();
        String sql = "SELECT `ID_Buku`,`JudulBuku`,`Penerbit`,`TanggalPinjam`,`TanggalKembali`"
                + " FROM `peminjaman` WHERE ID_Anggota" + ID_Anggota;
        try {
            ResultSet r = conn.createStatement().executeQuery(sql);
            while (r.next()){
                data.add(new Peminjaman(r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5)));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PeminjamanDataModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }
    public int nextPeminjamanIDAnggota() throws SQLException{
        String sql = "SELECT  MAX (ID_Anggota) from kartuanggota";
        ResultSet r = conn.createStatement().executeQuery(sql);
        while (r.next()){
            return r.getInt(1)==0?1000001:r.getInt(1)+1;
        }
        return 1000001;
    }
}
