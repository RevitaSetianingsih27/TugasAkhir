/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasAkhir;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author acer
 */
public class Peminjaman {
    public IntegerProperty IDBuku;
    public StringProperty JudulBuku;
    public StringProperty Penerbit;
    public StringProperty TanggalPinjam;
    public StringProperty TanggalKembali;

    public Peminjaman(Integer IDBuku, String JudulBuku, String Penerbit,
            String TanggalPinjam, String TanggalKembali) {
        this.IDBuku = new SimpleIntegerProperty(IDBuku);
        this.JudulBuku = new SimpleStringProperty(JudulBuku);
        this.Penerbit = new SimpleStringProperty(Penerbit);
        this.TanggalPinjam = new SimpleStringProperty(TanggalPinjam);
        this.TanggalKembali = new SimpleStringProperty(TanggalKembali);
    }

    public Integer getIDBuku() {
        return IDBuku.get();
    }

    public void setIDBuku(Integer IDBuku) {
        this.IDBuku.set(IDBuku);
    }

    public String getJudulBuku() {
        return JudulBuku.get();
    }

    public void setJudulBuku(String JudulBuku) {
        this.JudulBuku.set(JudulBuku);
    }

    public String getPenerbit() {
        return Penerbit.get();
    }

    public void setPenerbit(String Penerbit) {
        this.Penerbit.set(Penerbit);
    }

    public String getTanggalPinjam() {
        return TanggalPinjam.get();
    }

    public void setTanggalPinjam(String TanggalPinjam) {
        this.TanggalPinjam.set(TanggalPinjam);
    }

    public String getTanggalKembali() {
        return TanggalKembali.get();
    }

    public void setTanggalKembali(String TanggalKembali) {
        this.TanggalKembali.set(TanggalKembali);
    }
    
    public IntegerProperty IDBukuProperty(){
        return IDBuku;
    }
    public StringProperty JudulBukuProperty(){
        return JudulBuku;
    }
    public StringProperty PenerbitProperty(){
        return Penerbit;
    }
    public StringProperty TanggalPinjamProperty(){
        return TanggalPinjam;
    }
    public StringProperty TanggalKembaliProperty(){
        return TanggalKembali;
    }
}
