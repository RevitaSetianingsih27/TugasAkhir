/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasAkhir;

import java.util.ArrayList;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author acer
 */
public abstract class KartuAnggota {
    private IntegerProperty ID_Anggota;
    private StringProperty Nama;
    private IntegerProperty Usia;
    private StringProperty Gender;
    private IntegerProperty NomorHP;
    private StringProperty Alamat;
    private ArrayList<Peminjaman>Pinjam;
    

    public KartuAnggota(Integer ID_Anggota, String Nama, Integer Usia, String Gender,
            Integer NomorHP, String Alamat, ArrayList<Peminjaman>Pinjam) {
        this.ID_Anggota = new SimpleIntegerProperty(ID_Anggota);
        this.Nama = new SimpleStringProperty(Nama);
        this.Usia = new SimpleIntegerProperty(Usia);
        this.Gender = new SimpleStringProperty(Gender);
        this.NomorHP = new SimpleIntegerProperty(NomorHP);
        this.Alamat = new SimpleStringProperty(Alamat);
        this.Pinjam = Pinjam;
    }
    
    public KartuAnggota(Integer ID_Anggota, String Nama, Integer Usia, String Gender,
            Integer NomorHP, String Alamat, Peminjaman Peminjam) {
        Pinjam = new ArrayList<>();
        this.ID_Anggota = new SimpleIntegerProperty(ID_Anggota);
        this.Nama = new SimpleStringProperty(Nama);
        this.Usia = new SimpleIntegerProperty(Usia);
        this.Gender = new SimpleStringProperty(Gender);
        this.NomorHP = new SimpleIntegerProperty(NomorHP);
        this.Alamat = new SimpleStringProperty(Alamat);
        this.Pinjam.add(Peminjam);
    }

    public Integer getID_Anggota() {
        return ID_Anggota.get();
    }

    public void setID_Anggota(Integer ID_Anggota) {
        this.ID_Anggota.set(ID_Anggota);
    }
    
    
    public String getNama() {
        return Nama.get();
    }

    public void setNama(String Nama) {
        this.Nama.set(Nama);
    }

    public Integer getUsia() {
        return Usia.get();
    }

    public void setUsia(Integer Usia) {
        this.Usia.set(Usia);
    }

    public String getGender() {
        return Gender.get();
    }

    public void setGender(String Gender) {
        this.Gender.set(Gender);
    }

    public Integer getNomorHP() {
        return NomorHP.get();
    }

    public void setNomorHP(Integer NomorHP) {
        this.NomorHP.set(NomorHP);
    }

    public String getAlamat() {
        return Alamat.get();
    }

    public void setAlamat(String Alamat) {
        this.Alamat.set(Alamat);
    }

    public ArrayList<Peminjaman> getPinjam() {
        return Pinjam;
    }

    public void setPinjam(ArrayList<Peminjaman> Pinjam) {
        this.Pinjam = Pinjam;
    }
    
    public IntegerProperty ID_Anggota(){
        return ID_Anggota;
    }
    public StringProperty NamaProperty(){
        return Nama;
    }
    public IntegerProperty UsiaProperty(){
        return Usia;
    }
    public StringProperty GenderProperty(){
        return Gender;
    }
    public IntegerProperty NomorHPProperty(){
        return NomorHP;
    }
    public StringProperty AlamatProperty(){
        return Alamat;
    }
    
}