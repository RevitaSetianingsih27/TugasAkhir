/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasAkhir;

import java.util.ArrayList;

/**
 *
 * @author acer
 */
public class NonMahasiswa extends KartuAnggota {

    public NonMahasiswa(Integer ID_Anggota, String Nama, Integer Usia,
            String Gender, Integer NomorHP, String Alamat, ArrayList<Peminjaman> Pinjam) {
        super(ID_Anggota, Nama, Usia, Gender, NomorHP, Alamat, Pinjam);
    }

    public NonMahasiswa(Integer ID_Anggota, String Nama, Integer Usia, String Gender, Integer NomorHP, String Alamat, Peminjaman Peminjam) {
        super(ID_Anggota, Nama, Usia, Gender, NomorHP, Alamat, Peminjam);
    }
    
}
