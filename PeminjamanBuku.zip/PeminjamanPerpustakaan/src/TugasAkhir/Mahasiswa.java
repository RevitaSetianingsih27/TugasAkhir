/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TugasAkhir;

import java.util.ArrayList;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author acer
 */
public class Mahasiswa extends KartuAnggota {
    StringProperty Email;

    public Mahasiswa(Integer ID_Anggota, String Nama, Integer Usia, String Gender, Integer NomorHP,
            String Alamat, String Email, ArrayList<Peminjaman> Pinjam) {
        super(ID_Anggota, Nama, Usia, Gender, NomorHP, Alamat, Pinjam);
        this.Email = new SimpleStringProperty(Email);
    }

    public Mahasiswa(Integer ID_Anggota, String Nama, Integer Usia, String Gender, Integer NomorHP,
            String Alamat, String Email, Peminjaman Peminjam) {
        super(ID_Anggota, Nama, Usia, Gender, NomorHP, Alamat, Peminjam);
        this.Email = new SimpleStringProperty(Email);
    }


    public String getEmail() {
        return Email.get();
    }

    public void setEmail(String Email) {
        this.Email.set(Email);
    }
    
    public StringProperty EmailProperty() {
        return Email;
    }
    
}
